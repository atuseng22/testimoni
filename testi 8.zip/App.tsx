import { useEffect, useState } from 'react';
import { LayoutDashboard, Newspaper, Users, BarChart3, Sparkles, Volume2, VolumeX, Settings, Bitcoin, DollarSign, MessageCircle, Rocket } from 'lucide-react';
import { DashboardView } from '@/views/DashboardView';
import { NewsView } from '@/views/NewsView';
import { PeopleView } from '@/views/PeopleView';
import { MarketView } from '@/views/MarketView';
import { AiView } from '@/views/AiView';
import { SettingsView } from '@/views/SettingsView';
import { SocialView } from '@/views/SocialView';
import { CryptoView } from '@/views/CryptoView';
import { ForexView } from '@/views/ForexView';
import { IhsgView } from '@/views/IhsgView';
import { IpoView } from '@/views/IpoView';
import { stockSymbols, analyze, Stock } from '@/data/seed';
import { sfx, primeAudio, setMuted } from '@/utils/sound';
import { useSettings } from '@/lib/settings';

const tabs = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'news', label: 'Berita', icon: Newspaper },
  { id: 'people', label: 'Cari Profil', icon: Users },
  { id: 'market', label: 'Pasar Modal', icon: BarChart3 },
  { id: 'ipo', label: 'IPO', icon: Rocket },
  { id: 'social', label: 'Social', icon: MessageCircle },
  { id: 'crypto', label: 'Crypto', icon: Bitcoin },
  { id: 'forex', label: 'Forex', icon: DollarSign },
  { id: 'ai', label: 'AI Asisten', icon: Sparkles },
  { id: 'settings', label: 'Setting', icon: Settings },
] as const;
// 'ihsg' is a virtual tab — not shown in nav, only reachable from Dashboard button
// 'ipo' is reachable from nav

type TabId = (typeof tabs)[number]['id'] | 'ihsg';

type TickerItem = { symbol: string; last: number; change: number; changePct: number };

export default function App() {
  const { settings } = useSettings();
  const [tab, setTab] = useState<TabId>('dashboard');
  const [tickerItems, setTickerItems] = useState<TickerItem[]>([]);

  // Sync mute state with settings
  useEffect(() => {
    setMuted(!settings.soundEnabled);
  }, [settings.soundEnabled]);

  // Fetch live ticker data from market-breadth edge function (all 850 stocks)
  useEffect(() => {
    let active = true;
    const fetchTicker = async () => {
      try {
        const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/market-breadth`;
        const resp = await fetch(url, {
          headers: {
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
        });
        if (!resp.ok) return;
        const json = await resp.json();
        if (json.error) return;
        // Use the ticker array from the edge function — top 30 stocks by trading value
        const all: TickerItem[] = (json.ticker || []).map((s: { symbol: string; last: number; change: number; changePct: number }) => ({
          symbol: s.symbol, last: s.last, change: s.change, changePct: s.changePct,
        }));
        if (active && all.length > 0) setTickerItems(all);
      } catch {
        // keep existing
      }
    };
    void fetchTicker();
    const t = setInterval(() => void fetchTicker(), 30000);
    return () => { active = false; clearInterval(t); };
  }, []);

  const go = (id: string) => {
    if (id === tab) return;
    sfx.tab();
    setTab(id as TabId);
  };

  const toggleMute = () => {
    sfx.click();
    setMuted(settings.soundEnabled);
    // Toggle via settings by flipping soundEnabled
    // This is handled by the settings hook, but we also toggle directly here
  };

  // prime audio on first interaction
  useEffect(() => {
    const handler = () => {
      primeAudio();
      window.removeEventListener('pointerdown', handler);
    };
    window.addEventListener('pointerdown', handler);
    return () => window.removeEventListener('pointerdown', handler);
  }, []);

  return (
    <div className="relative min-h-screen">
      <div className="app-bg" />
      <div className="grain" />

      {/* Kepala aplikasi */}
      <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-ink-950/70 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3.5 md:px-6">
          <div className="flex items-center gap-3.5">
            <div className="sheen relative grid h-11 w-11 place-items-center rounded-[14px] bg-gradient-to-br from-primary-300 via-primary-500 to-primary-700 shadow-glow">
              <span className="text-[13px] font-bold tracking-tightest text-ink-950">FDC</span>
              <span className="absolute -right-0.5 -top-0.5 h-3 w-3 rounded-full border-[2.5px] border-ink-950 bg-success-400" />
            </div>
            <div className="leading-none">
              <div className="judul text-[17px] text-slate-50">
                FDC <span className="teks-gradasi">Markets</span>
              </div>
              <div className="mt-1.5 flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.18em] text-slate-500">
                Bursa Efek Indonesia
                <span className="h-1 w-1 rounded-full bg-slate-700" />
                Real time
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="hidden items-center gap-2 rounded-full border border-success-500/25 bg-success-500/[0.08] px-3 py-1.5 text-[11px] font-semibold tracking-wide text-success-400 sm:flex">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success-500 opacity-70" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-success-400" />
              </span>
              ONLINE
            </span>
            <button
              onClick={() => { if (settings.soundEnabled) { sfx.toggle(); setMuted(true); } else { setMuted(false); sfx.pop(); } window.dispatchEvent(new Event('fariz-mute-toggle')); }}
              className="press grid h-9.5 w-9.5 place-items-center rounded-xl border border-white/[0.07] bg-white/[0.03] text-slate-400 transition hover:border-primary-500/35 hover:text-primary-300"
              aria-label={settings.soundEnabled ? 'Matikan suara' : 'Aktifkan suara'}
            >
              {settings.soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </button>
          </div>
        </div>

        {/* Navigasi */}
        <nav className="mx-auto max-w-7xl px-2 md:px-4">
          <div className="no-scrollbar flex gap-1.5 overflow-x-auto pb-2.5">
            {tabs.map((t) => {
              const Icon = t.icon;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => go(t.id)}
                  className={`press relative flex flex-shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-[13px] font-medium transition-colors duration-200 ${
                    active
                      ? 'bg-primary-500/[0.14] text-primary-200 ring-1 ring-inset ring-primary-400/25'
                      : 'text-slate-500 hover:bg-white/[0.04] hover:text-slate-200'
                  }`}
                >
                  <Icon className={`h-4 w-4 ${active ? 'text-primary-300' : ''}`} />
                  {t.label}
                </button>
              );
            })}
          </div>
        </nav>

        {/* Pita harga berjalan */}
        <div className="relative border-t border-white/[0.05] bg-ink-900/50">
          <div className="flex items-center overflow-hidden">
            <span className="relative z-10 flex flex-shrink-0 items-center gap-1.5 bg-ink-950/90 px-3.5 py-2 text-[10px] font-bold uppercase tracking-[0.16em] text-primary-300">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary-400 opacity-70" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-primary-400" />
              </span>
              Live
            </span>
            <div className="relative flex-1 overflow-hidden">
              <div className="flex animate-ticker whitespace-nowrap py-2">
                {tickerItems.length > 0 ? (
                  [...tickerItems, ...tickerItems].map((t, i) => (
                    <span key={i} className="mx-5 flex items-center gap-2 text-xs">
                      <span className="font-semibold tracking-wide text-slate-300">{t.symbol}</span>
                      <span className="tnum text-slate-500">{t.last.toLocaleString('id-ID')}</span>
                      <span className={`tnum font-semibold ${t.change >= 0 ? 'text-success-400' : 'text-danger-400'}`}>
                        {t.change > 0 ? '+' : ''}{t.changePct}%
                      </span>
                    </span>
                  ))
                ) : (
                  <span className="mx-5 text-xs text-slate-600">Menarik data pasar…</span>
                )}
              </div>
              {/* tepi kanan meredup agar pita tidak terpotong tajam */}
              <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-ink-900/90 to-transparent" />
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="relative z-10 mx-auto max-w-7xl px-4 py-6 md:px-6 md:py-8">
        <div key={tab} className="animate-fade-in">
          {tab === 'dashboard' && <DashboardView onNavigate={go} />}
          {tab === 'news' && <NewsView />}
          {tab === 'people' && <PeopleView />}
          {tab === 'market' && <MarketView />}
          {tab === 'ipo' && <IpoView onBack={() => go('dashboard')} />}
          {tab === 'social' && <SocialView />}
          {tab === 'crypto' && <CryptoView onBack={() => go('dashboard')} />}
          {tab === 'forex' && <ForexView onBack={() => go('dashboard')} />}
          {tab === 'ai' && <AiView />}
          {tab === 'settings' && <SettingsView />}
          {tab === 'ihsg' && <IhsgView onBack={() => go('dashboard')} />}
        </div>
      </main>

      <footer className="relative z-10 border-t border-ink-800/60 px-4 py-6 text-center md:px-6">
        <p className="text-xs text-slate-500">
          FDC: Stocks, Markets &amp; News — Platform Intelijen Pasar Modal Indonesia. Data pasar real-time dari Yahoo Finance, berita dari sumber terpercaya.
        </p>
      </footer>
    </div>
  );
}
