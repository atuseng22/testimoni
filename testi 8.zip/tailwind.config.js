/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        /* permukaan gelap berlapis, sedikit condong ke biru dingin */
        ink: {
          950: '#04070a',
          900: '#070c12',
          850: '#0b121a',
          800: '#111a24',
          700: '#1a2632',
          600: '#243444',
          500: '#33475c',
        },
        /* hijau zamrud sebagai warna utama */
        primary: {
          50:  '#e8fff8',
          100: '#c9ffee',
          200: '#93fadd',
          300: '#4fefc7',
          400: '#1fdcae',
          500: '#0bbd92',
          600: '#059674',
          700: '#06765d',
          800: '#075c4a',
          900: '#074a3d',
        },
        /* kuning tembaga untuk penekanan */
        accent: {
          300: '#ffd98a',
          400: '#ffc44d',
          500: '#f5a524',
          600: '#d98410',
        },
        success: { 400: '#3ddc97', 500: '#1fbf7a', 600: '#159c62' },
        danger:  { 400: '#ff7089', 500: '#f5495f', 600: '#d62f47' },
      },
      fontFamily: {
        sans:    ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        mono:    ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
      },
      letterSpacing: { tightest: '-0.045em' },
      borderRadius: { '4xl': '2rem' },
      boxShadow: {
        lift:  '0 24px 60px -24px rgba(0,0,0,0.75)',
        glow:  '0 0 32px -6px rgba(31,220,174,0.35)',
        inner1: 'inset 0 1px 0 rgba(255,255,255,0.06)',
      },
      animation: {
        'fade-in':    'fadeIn 0.5s ease forwards',
        'slide-up':   'slideUp 0.55s cubic-bezier(0.16,1,0.3,1) forwards',
        'slide-down': 'slideDown 0.4s ease forwards',
        'scale-in':   'scaleIn 0.34s cubic-bezier(0.16,1,0.3,1) forwards',
        'pulse-glow': 'pulseGlow 2.4s ease-in-out infinite',
        'spin-slow':  'spin 8s linear infinite',
        'ticker':     'ticker 44s linear infinite',
        'shimmer':    'shimmer 2.2s linear infinite',
        'float':      'float 7s ease-in-out infinite',
        'aurora':     'aurora 22s ease-in-out infinite',
        'sheen':      'sheen 3.6s ease-in-out infinite',
      },
      keyframes: {
        fadeIn:    { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        slideUp:   { '0%': { opacity: '0', transform: 'translateY(22px)' }, '100%': { opacity: '1', transform: 'none' } },
        slideDown: { '0%': { opacity: '0', transform: 'translateY(-12px)' }, '100%': { opacity: '1', transform: 'none' } },
        scaleIn:   { '0%': { opacity: '0', transform: 'scale(0.94)' }, '100%': { opacity: '1', transform: 'scale(1)' } },
        pulseGlow: { '0%,100%': { boxShadow: '0 0 0 0 rgba(31,220,174,0.38)' }, '50%': { boxShadow: '0 0 26px 5px rgba(31,220,174,0.22)' } },
        ticker:    { '0%': { transform: 'translateX(0)' }, '100%': { transform: 'translateX(-50%)' } },
        shimmer:   { '0%': { backgroundPosition: '-200% 0' }, '100%': { backgroundPosition: '200% 0' } },
        float:     { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-9px)' } },
        aurora: {
          '0%,100%': { transform: 'translate3d(0,0,0) scale(1)',       opacity: '0.55' },
          '33%':     { transform: 'translate3d(4%,-3%,0) scale(1.12)', opacity: '0.75' },
          '66%':     { transform: 'translate3d(-3%,4%,0) scale(0.95)', opacity: '0.45' },
        },
        sheen: {
          '0%':      { transform: 'translateX(-120%)' },
          '55%,100%':{ transform: 'translateX(220%)' },
        },
      },
    },
  },
  plugins: [],
};
