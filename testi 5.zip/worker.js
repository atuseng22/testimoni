/* =========================================================================
   FDC — proxy berita  (Cloudflare Worker)
   -------------------------------------------------------------------------
   Kenapa perlu: browser dilarang mengambil RSS media secara langsung
   karena aturan CORS. Worker ini yang mengambilkan, merapikan, lalu
   mengirim hasilnya ke aplikasi dalam bentuk JSON.

   Cara pasang:
     1. Buat akun di dash.cloudflare.com (gratis)
     2. Workers & Pages  →  Create  →  Worker  →  Deploy
     3. Edit code, tempel seluruh isi berkas ini, lalu Deploy lagi
     4. Salin alamatnya, misalnya https://fdc-berita.nama-anda.workers.dev
     5. Buka index.html, isi:  const NEWS_API = 'https://fdc-berita...workers.dev';

   Uji cepat: buka alamat worker di browser. Kalau muncul JSON berisi
   judul-judul berita, berarti sudah jalan.
   ========================================================================= */

const SOURCES = [
  { id:'cnbc',     rss:'https://www.cnbcindonesia.com/market/rss' },
  { id:'kontan',   rss:'https://rss.kontan.co.id/news/investasi' },
  { id:'kontan',   rss:'https://rss.kontan.co.id/news/keuangan' },
  { id:'bisnis',   rss:'https://market.bisnis.com/rss' },
  { id:'antara',   rss:'https://www.antaranews.com/rss/ekonomi.xml' },
  { id:'cnn',      rss:'https://www.cnnindonesia.com/ekonomi/rss' },
  { id:'liputan6', rss:'https://feed.liputan6.com/rss/bisnis' },
  { id:'tempo',    rss:'https://rss.tempo.co/bisnis' }
];

/* kode emiten yang ditandai otomatis di judul */
const TICKERS = ['BBCA','BBRI','BMRI','BBNI','BRIS','BTPN','BDMN','BBTN','PNBN',
  'TLKM','ASII','ICBP','INDF','UNVR','ADRO','ANTM','GOTO','AMMN','BREN','BYAN',
  'MDKA','ITMG','ISAT','EMAS','BRMS','DCII','BELI','ARCI','BRPT','ESSA','DSSA'];

const NAIK  = /naik|menguat|melejit|melesat|rebound|reli|untung|cuan|lonjak|tancap|hijau|rekor|dividen|buyback/i;
const TURUN = /turun|melemah|anjlok|ambruk|merosot|jeblok|lesu|tertekan|merah|koreksi|rugi|suspensi/i;

function nada(judul){
  if (TURUN.test(judul)) return 'down';
  if (NAIK.test(judul))  return 'up';
  return 'flat';
}

function kodeEmiten(judul){
  const kena = TICKERS.filter(t => new RegExp('\\b' + t + '\\b').test(judul));
  return kena.slice(0, 3);
}

/* pembaca XML sederhana — cukup untuk RSS dan Atom */
function ambilTag(blok, tag){
  const m = blok.match(new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)<\\/' + tag + '>', 'i'));
  return m ? m[1] : '';
}
function bersih(teks){
  return teks
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#8217;|&rsquo;/g, "'").replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function uraikan(xml, sumber){
  const potongan = xml.match(/<item[\s\S]*?<\/item>/gi) || xml.match(/<entry[\s\S]*?<\/entry>/gi) || [];
  return potongan.map(p => {
    const judul = bersih(ambilTag(p, 'title'));
    let tautan = bersih(ambilTag(p, 'link'));
    if (!tautan) {
      const alt = p.match(/<link[^>]*href="([^"]+)"/i);
      tautan = alt ? alt[1] : '';
    }
    tautan = tautan.replace(/\/amp\/?$/, '');           // buang versi AMP
    const waktu = bersih(ambilTag(p, 'pubDate')) || bersih(ambilTag(p, 'published')) || bersih(ambilTag(p, 'updated'));
    const t = waktu ? new Date(waktu) : new Date();
    return {
      id: tautan || judul,
      title: judul,
      url: tautan,
      source: sumber,
      publishedAt: isNaN(t) ? new Date().toISOString() : t.toISOString(),
      tone: nada(judul),
      tickers: kodeEmiten(judul)
    };
  }).filter(n => n.title && n.url);
}

async function tarik(src){
  try{
    const r = await fetch(src.rss, {
      cf: { cacheTtl: 240, cacheEverything: true },
      headers: { 'user-agent': 'FDC-News-Reader/1.0' }
    });
    if (!r.ok) return [];
    return uraikan(await r.text(), src.id);
  }catch(e){
    return [];                                          // satu feed mati, sisanya tetap jalan
  }
}

/* ---------------- data pasar (indeks & kutipan saham) ---------------- */
const KUTIPAN = 'https://query1.finance.yahoo.com/v8/finance/chart/';

async function kutipan(simbol, range, interval){
  const alamat = KUTIPAN + encodeURIComponent(simbol) +
    '?range=' + (range || '1d') + '&interval=' + (interval || '5m');
  const r = await fetch(alamat, {
    cf: { cacheTtl: 45, cacheEverything: true },
    headers: { 'user-agent': 'Mozilla/5.0 (compatible; FDC/1.0)', accept: 'application/json' }
  });
  if (!r.ok) throw new Error('kutipan gagal: ' + r.status);
  return await r.json();
}


/* =========================================================================
   LANGGANAN PRO — QRIS & GoPay lewat Midtrans
   -------------------------------------------------------------------------
   Yang harus disiapkan sekali di Cloudflare:

   1. Settings → Variables → tambahkan secret:
        MIDTRANS_SERVER_KEY   = Server Key dari dashboard Midtrans
        MIDTRANS_PRODUKSI     = "1" bila sudah live, kosongkan bila sandbox
   2. Settings → Bindings → KV namespace:
        Variable name: LISENSI     (buat namespace baru bernama fdc-lisensi)
   3. Di dashboard Midtrans → Settings → Configuration:
        Payment Notification URL = https://alamat-worker-anda/notifikasi

   Server Key TIDAK BOLEH ditaruh di index.html. Ia hanya hidup di sini.
   ========================================================================= */

const PAKET = {
  bulanan:  { nama: 'Pro Bulanan',  harga: 29000,  hari: 30 },
  tahunan:  { nama: 'Pro Tahunan',  harga: 290000, hari: 365 }
};

function alamatMidtrans(env){
  return env.MIDTRANS_PRODUKSI === '1'
    ? 'https://api.midtrans.com/v2/charge'
    : 'https://api.sandbox.midtrans.com/v2/charge';
}

function kodeLisensi(){
  const huruf = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let k = '';
  for (let i = 0; i < 16; i++){
    if (i && i % 4 === 0) k += '-';
    k += huruf[Math.floor(Math.random() * huruf.length)];
  }
  return 'FDC-' + k;
}

async function sha512(teks){
  const buf = await crypto.subtle.digest('SHA-512', new TextEncoder().encode(teks));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ---- membuat tagihan QRIS atau GoPay ---- */
async function buatTagihan(request, env, cors){
  let badan = {};
  try{ badan = await request.json(); }catch(e){}

  const paket = PAKET[badan.paket] || PAKET.bulanan;
  const cara  = badan.cara === 'gopay' ? 'gopay' : 'qris';
  const orderId = 'FDC-' + Date.now().toString(36).toUpperCase() + '-' +
                  Math.random().toString(36).slice(2, 6).toUpperCase();

  const isi = {
    payment_type: cara,
    transaction_details: { order_id: orderId, gross_amount: paket.harga },
    item_details: [{ id: badan.paket || 'bulanan', price: paket.harga, quantity: 1, name: paket.nama }],
    customer_details: {
      first_name: (badan.nama || 'Pengguna FDC').slice(0, 40),
      email: (badan.email || '').slice(0, 60)
    }
  };
  if (cara === 'qris') isi.qris = { acquirer: 'gopay' };

  const sandi = btoa(env.MIDTRANS_SERVER_KEY + ':');
  const r = await fetch(alamatMidtrans(env), {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json',
               authorization: 'Basic ' + sandi },
    body: JSON.stringify(isi)
  });
  const j = await r.json();

  if (!r.ok || (j.status_code && Number(j.status_code) >= 400)){
    return new Response(JSON.stringify({ galat: j.status_message || 'gagal membuat tagihan' }), {
      status: 502, headers: { ...cors, 'content-type': 'application/json' }
    });
  }

  /* simpan tagihan supaya webhook nanti tahu paketnya */
  await env.LISENSI.put('order:' + orderId, JSON.stringify({
    paket: badan.paket || 'bulanan',
    email: badan.email || '',
    harga: paket.harga,
    dibuat: Date.now()
  }), { expirationTtl: 86400 });

  const aksi = j.actions || [];
  const cari = n => (aksi.find(a => a.name === n) || {}).url || '';

  return new Response(JSON.stringify({
    orderId,
    cara,
    paket: paket.nama,
    harga: paket.harga,
    kedaluwarsa: j.expiry_time || null,
    gambarQr: cari('generate-qr-code'),
    tautanGopay: cari('deeplink-redirect'),
    tautanStatus: cari('get-status')
  }), { headers: { ...cors, 'content-type': 'application/json' } });
}

/* ---- webhook dari Midtrans ---- */
async function terimaNotifikasi(request, env, cors){
  let n = {};
  try{ n = await request.json(); }catch(e){
    return new Response('badan tidak terbaca', { status: 400, headers: cors });
  }

  /* tanda tangan wajib cocok, kalau tidak permintaan diabaikan */
  const tandaSeharusnya = await sha512(
    String(n.order_id) + String(n.status_code) + String(n.gross_amount) + env.MIDTRANS_SERVER_KEY
  );
  if (tandaSeharusnya !== n.signature_key){
    return new Response('tanda tangan tidak cocok', { status: 403, headers: cors });
  }

  const lunas = (n.transaction_status === 'settlement' || n.transaction_status === 'capture') &&
                n.fraud_status !== 'deny';
  if (!lunas) return new Response('ok', { headers: cors });

  const mentah = await env.LISENSI.get('order:' + n.order_id);
  const order = mentah ? JSON.parse(mentah) : { paket: 'bulanan' };
  const paket = PAKET[order.paket] || PAKET.bulanan;

  const kode = kodeLisensi();
  const berlaku = Date.now() + paket.hari * 86400000;

  await env.LISENSI.put('lisensi:' + kode, JSON.stringify({
    orderId: n.order_id,
    paket: order.paket,
    email: order.email || '',
    mulai: Date.now(),
    berlaku,
    aktif: true
  }), { expirationTtl: paket.hari * 86400 + 86400 });

  /* supaya aplikasi bisa menjemput kodenya tanpa pengguna mengetik */
  await env.LISENSI.put('order-kode:' + n.order_id, kode, { expirationTtl: 86400 * 7 });

  return new Response('ok', { headers: cors });
}

/* ---- aplikasi menanyakan status ---- */
async function cekLisensi(url, env, cors){
  const kode = (url.searchParams.get('kode') || '').trim().toUpperCase();
  const order = (url.searchParams.get('order') || '').trim();

  let kunci = kode;
  if (!kunci && order){
    kunci = (await env.LISENSI.get('order-kode:' + order)) || '';
    if (!kunci){
      return new Response(JSON.stringify({ status: 'menunggu' }), {
        headers: { ...cors, 'content-type': 'application/json' }
      });
    }
  }
  if (!kunci){
    return new Response(JSON.stringify({ status: 'kosong' }), {
      status: 400, headers: { ...cors, 'content-type': 'application/json' }
    });
  }

  const mentah = await env.LISENSI.get('lisensi:' + kunci);
  if (!mentah){
    return new Response(JSON.stringify({ status: 'tidak-ditemukan' }), {
      headers: { ...cors, 'content-type': 'application/json' }
    });
  }

  const l = JSON.parse(mentah);
  const hidup = l.aktif && l.berlaku > Date.now();
  return new Response(JSON.stringify({
    status: hidup ? 'aktif' : 'kedaluwarsa',
    kode: kunci,
    paket: l.paket,
    berlaku: l.berlaku,
    sisaHari: Math.max(0, Math.ceil((l.berlaku - Date.now()) / 86400000))
  }), { headers: { ...cors, 'content-type': 'application/json' } });
}

export default {
  async fetch(request, env){
    const asal = request.headers.get('Origin') || '*';
    const cors = {
      'access-control-allow-origin': asal,
      'access-control-allow-methods': 'GET,OPTIONS',
      'cache-control': 'public, max-age=120'
    };
    if (request.method === 'OPTIONS') return new Response(null, { headers: cors });

    const jalur = new URL(request.url).pathname.replace(/\/+$/, '');
    const q = new URL(request.url).searchParams;

    /* ---- /pasar : data indeks IHSG ---- */
    if (jalur.endsWith('/pasar')){
      try{
        const j = await kutipan('^JKSE', q.get('range') || '1d', q.get('interval') || '5m');
        return new Response(JSON.stringify(j), {
          headers: { ...cors, 'content-type': 'application/json; charset=utf-8' }
        });
      }catch(e){
        return new Response(JSON.stringify({ error: String(e) }), {
          status: 502, headers: { ...cors, 'content-type': 'application/json' }
        });
      }
    }

    /* ---- /kutipan?sym=BBCA.JK : data satu saham ---- */
    if (jalur.endsWith('/kutipan')){
      const sym = q.get('sym') || 'BBCA.JK';
      try{
        const j = await kutipan(sym, q.get('range') || '5d', q.get('interval') || '1d');
        return new Response(JSON.stringify(j), {
          headers: { ...cors, 'content-type': 'application/json; charset=utf-8' }
        });
      }catch(e){
        return new Response(JSON.stringify({ error: String(e) }), {
          status: 502, headers: { ...cors, 'content-type': 'application/json' }
        });
      }
    }

    /* ---- /ipo : jadwal pencatatan saham baru ---- */
    if (jalur.endsWith('/ipo')){
      try{
        const r = await fetch('https://www.e-ipo.co.id/id/ipo/index?view=list', {
          cf: { cacheTtl: 3600, cacheEverything: true },
          headers: { 'user-agent': 'Mozilla/5.0 (compatible; FDC/1.0)' }
        });
        if (r.ok){
          const html = await r.text();
          return new Response(JSON.stringify({ html }), {
            headers: { ...cors, 'content-type': 'application/json; charset=utf-8',
                       'cache-control': 'public, max-age=3600' }
          });
        }
      }catch(e){ /* menyerah dengan tenang */ }
      return new Response(JSON.stringify({ html: '' }), {
        status: 502, headers: { ...cors, 'content-type': 'application/json' }
      });
    }

    /* ---- /bayar : membuat tagihan QRIS atau GoPay ---- */
    if (jalur.endsWith('/bayar')){
      if (request.method !== 'POST')
        return new Response(JSON.stringify({ galat: 'gunakan POST' }), { status: 405, headers: { ...cors, 'content-type': 'application/json' } });
      if (!env.MIDTRANS_SERVER_KEY)
        return new Response(JSON.stringify({ galat: 'MIDTRANS_SERVER_KEY belum dipasang di worker' }), { status: 500, headers: { ...cors, 'content-type': 'application/json' } });
      try{ return await buatTagihan(request, env, cors); }
      catch(e){ return new Response(JSON.stringify({ galat: String(e) }), { status: 500, headers: { ...cors, 'content-type': 'application/json' } }); }
    }

    /* ---- /notifikasi : webhook dari Midtrans ---- */
    if (jalur.endsWith('/notifikasi')){
      if (request.method !== 'POST') return new Response('gunakan POST', { status: 405, headers: cors });
      try{ return await terimaNotifikasi(request, env, cors); }
      catch(e){ return new Response('galat', { status: 500, headers: cors }); }
    }

    /* ---- /lisensi : aplikasi memeriksa status langganan ---- */
    if (jalur.endsWith('/lisensi')){
      try{ return await cekLisensi(new URL(request.url), env, cors); }
      catch(e){ return new Response(JSON.stringify({ status: 'galat' }), { status: 500, headers: { ...cors, 'content-type': 'application/json' } }); }
    }

    /* ---- /fundamental?sym=BBCA : laporan keuangan per kuartal ---- */
    if (jalur.endsWith('/fundamental')){
      const sym = (q.get('sym') || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 5);
      if (!sym) return new Response(JSON.stringify({ error: 'kode kosong' }), {
        status: 400, headers: { ...cors, 'content-type': 'application/json' }
      });
      const jenis = [
        'quarterlyTotalRevenue','quarterlyNetIncome','quarterlyGrossProfit',
        'quarterlyOperatingIncome','quarterlyTotalAssets',
        'quarterlyTotalLiabilitiesNetMinorityInterest','quarterlyStockholdersEquity',
        'quarterlyOperatingCashFlow','quarterlyInvestingCashFlow',
        'quarterlyFinancingCashFlow','quarterlyFreeCashFlow','quarterlyDilutedEPS'
      ].join(',');
      const akhir = Math.floor(Date.now() / 1000);
      const mulai = akhir - 3600 * 24 * 365 * 4;
      try{
        const r = await fetch(
          'https://query1.finance.yahoo.com/ws/fundamentals-timeseries/v1/finance/timeseries/' +
          sym + '.JK?symbol=' + sym + '.JK&type=' + jenis +
          '&period1=' + mulai + '&period2=' + akhir,
          { cf: { cacheTtl: 21600, cacheEverything: true },
            headers: { 'user-agent': 'Mozilla/5.0 (compatible; FDC/1.0)', accept: 'application/json' } });
        if (r.ok){
          const j = await r.json();
          return new Response(JSON.stringify(j), {
            headers: { ...cors, 'content-type': 'application/json; charset=utf-8',
                       'cache-control': 'public, max-age=21600' }
          });
        }
      }catch(e){ /* menyerah dengan tenang */ }
      return new Response(JSON.stringify({ error: 'laporan tidak ditemukan' }), {
        status: 502, headers: { ...cors, 'content-type': 'application/json' }
      });
    }

    /* ---- /profil?sym=BBCA : profil emiten dari papan pencatatan ---- */
    if (jalur.endsWith('/profil')){
      const sym = (q.get('sym') || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 5);
      if (!sym) return new Response(JSON.stringify({ error: 'kode kosong' }), {
        status: 400, headers: { ...cors, 'content-type': 'application/json' }
      });

      /* IDX menyimpan profil rinci termasuk alamat, telepon, dan pengurus */
      const sumber = [
        'https://www.idx.co.id/primary/ListedCompany/GetCompanyProfilesDetail?KodeEmiten=' + sym + '&language=id-id',
        'https://query1.finance.yahoo.com/v10/finance/quoteSummary/' + sym +
          '.JK?modules=assetProfile%2CsummaryProfile%2Cprice'
      ];
      for (const alamat of sumber){
        try{
          const r = await fetch(alamat, {
            cf: { cacheTtl: 43200, cacheEverything: true },
            headers: {
              'user-agent': 'Mozilla/5.0 (compatible; FDC/1.0)',
              accept: 'application/json',
              referer: 'https://www.idx.co.id/'
            }
          });
          if (!r.ok) continue;
          const j = await r.json();
          return new Response(JSON.stringify(j), {
            headers: { ...cors, 'content-type': 'application/json; charset=utf-8',
                       'cache-control': 'public, max-age=43200' }
          });
        }catch(e){ /* coba sumber berikutnya */ }
      }
      return new Response(JSON.stringify({ error: 'profil tidak ditemukan' }), {
        status: 502, headers: { ...cors, 'content-type': 'application/json' }
      });
    }

    /* ---- /emiten : daftar saham tercatat beserta statusnya ---- */
    if (jalur.endsWith('/emiten')){
      const sumber = [
        'https://www.idx.co.id/primary/StockData/GetSecuritiesStock?start=0&length=1200',
        'https://www.idx.co.id/primary/ListedCompany/GetCompanyProfiles?start=0&length=1200'
      ];
      for (const alamat of sumber){
        try{
          const r = await fetch(alamat, {
            cf: { cacheTtl: 3600, cacheEverything: true },
            headers: {
              'user-agent': 'Mozilla/5.0 (compatible; FDC/1.0)',
              accept: 'application/json',
              referer: 'https://www.idx.co.id/'
            }
          });
          if (!r.ok) continue;
          const j = await r.json();
          const arr = j.data || j.Data || j.results || (Array.isArray(j) ? j : null);
          if (!arr || !arr.length) continue;
          return new Response(JSON.stringify({ data: arr }), {
            headers: { ...cors, 'content-type': 'application/json; charset=utf-8',
                       'cache-control': 'public, max-age=3600' }
          });
        }catch(e){ /* coba sumber berikutnya */ }
      }
      /* IDX menolak, coba tabel emiten publik (memuat penanda delisting) */
      try{
        const r = await fetch('https://www.seputarforex.org/saham/daftar_emiten', {
          cf: { cacheTtl: 21600, cacheEverything: true },
          headers: { 'user-agent': 'Mozilla/5.0 (compatible; FDC/1.0)' }
        });
        if (r.ok){
          const html = await r.text();
          const baris = html.split(/<tr[\s>]/i);
          const data = [], lihat = {};
          for (let i = 1; i < baris.length; i++){
            const mk = baris[i].match(/harga\.php\?kode=([a-zA-Z]{3,5})\b/);
            if (!mk) continue;
            const kode = mk[1].toUpperCase();
            if (lihat[kode]) continue;
            lihat[kode] = 1;
            const delist = /kode=delisting/i.test(baris[i]);
            const sel = baris[i].split(/<\/td>/i).map(x =>
              x.replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim());
            let nama = kode;
            for (const isi of sel){
              if (!isi || isi === kode || /^\d+$/.test(isi) || isi.length < 3) continue;
              if (/^(ENERGY|FINANCIALS|PROPERTY|TECHNOLOGY|HEALTHCARE|INDUSTRIALS|TRANSPORTATION|INFRASTRUCTURE|DELISTING)/i.test(isi)) continue;
              nama = isi; break;
            }
            data.push({ Code: kode, Name: nama, Status: delist ? 'Delisting' : 'Aktif' });
          }
          if (data.length > 200){
            return new Response(JSON.stringify({ data }), {
              headers: { ...cors, 'content-type': 'application/json; charset=utf-8',
                         'cache-control': 'public, max-age=21600' }
            });
          }
        }
      }catch(e){ /* lanjut ke sumber berikutnya */ }

      /* masih gagal, coba kumpulan data terbuka */
      try{
        const r = await fetch('https://raw.githubusercontent.com/wildangunawan/Dataset-Saham-IDX/master/List%20Emiten/all.csv',
          { cf: { cacheTtl: 21600, cacheEverything: true } });
        if (r.ok){
          const teks = await r.text();
          const baris = teks.split(/\r?\n/).filter(x => x.trim());
          const kepala = baris[0].toLowerCase().split(',');
          const iKode = kepala.indexOf('code'), iNama = kepala.indexOf('name');
          const data = [];
          for (let i = 1; i < baris.length; i++){
            const sel = baris[i].split(',');
            const kode = (sel[iKode] || '').trim().toUpperCase();
            if (!/^[A-Z]{3,5}$/.test(kode)) continue;
            data.push({
              Code: kode,
              Name: (iNama >= 0 ? sel[iNama] : kode).trim(),
              ListingBoard: (sel[sel.length - 1] || '').trim()
            });
          }
          if (data.length){
            return new Response(JSON.stringify({ data }), {
              headers: { ...cors, 'content-type': 'application/json; charset=utf-8',
                         'cache-control': 'public, max-age=21600' }
            });
          }
        }
      }catch(e){ /* menyerah dengan tenang */ }

      return new Response(JSON.stringify({ data: [] }), {
        status: 502, headers: { ...cors, 'content-type': 'application/json' }
      });
    }

    /* ---- selain itu: umpan berita ---- */
    const hasil = await Promise.all(SOURCES.map(tarik));
    const semua = hasil.flat();

    // buang duplikat berdasarkan tautan, lalu urutkan dari yang terbaru
    const unik = [...new Map(semua.map(n => [n.url, n])).values()]
      .sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt))
      .slice(0, 60);

    return new Response(JSON.stringify(unik), {
      headers: { ...cors, 'content-type': 'application/json; charset=utf-8' }
    });
  }
};
